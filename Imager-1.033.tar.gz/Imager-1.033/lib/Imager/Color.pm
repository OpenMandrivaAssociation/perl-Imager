package Imager::Color;
use 5.006;
use Imager;
use strict;
use Scalar::Util ();
use POSIX ();

our $VERSION = "1.015";

# It's just a front end to the XS creation functions.

# used in converting hsv to rgb
my @hsv_map =
  (
   'vkm', 'nvm', 'mvk', 'mnv', 'kmv', 'vmn'
  );

sub _hsv_to_rgb {
  my ($hue, $sat, $val) = @_;

  # HSV conversions from pages 401-403 "Procedural Elements for Computer
  # Graphics", 1985, ISBN 0-07-053534-5.

  my @result;
  if ($sat <= 0) {
    return ( 255 * $val, 255 * $val, 255 * $val );
  }
  else {
    $val >= 0 or $val = 0;
    $val <= 1 or $val = 1;
    $sat <= 1 or $sat = 1;
    $hue >= 360 and $hue %= 360;
    $hue < 0 and $hue += 360;
    $hue /= 60.0;
    my $i = int($hue);
    my $f = $hue - $i;
    $val *= 255;
    my $m = $val * (1.0 - $sat);
    my $n = $val * (1.0 - $sat * $f);
    my $k = $val * (1.0 - $sat * (1 - $f));
    my $v = $val;
    my %fields = ( 'm'=>$m, 'n'=>$n, 'v'=>$v, 'k'=>$k, );
    return @fields{split //, $hsv_map[$i]};
  }
}

# cache of loaded gimp files
# each key is a filename, under each key is a hashref with the following
# keys:
#   mod_time => last mod_time of file
#   colors => hashref name to arrayref of colors
my %gimp_cache;

# palette search locations
# this is pretty rude
# $HOME is replaced at runtime
my @gimp_search =
  (
   '$HOME/.gimp-1.2/palettes/Named_Colors',
   '$HOME/.gimp-1.1/palettes/Named_Colors',
   '$HOME/.gimp/palettes/Named_Colors',
   '/usr/share/gimp/1.2/palettes/Named_Colors',
   '/usr/share/gimp/1.1/palettes/Named_Colors',
   '/usr/share/gimp/palettes/Named_Colors',
  );

my $default_gimp_palette;

sub _load_gimp_palette {
  my ($filename) = @_;

  if (open PAL, "< $filename") {
    my $hdr = <PAL>;
    chomp $hdr;
    unless ($hdr =~ /GIMP Palette/) {
      close PAL;
      $Imager::ERRSTR = "$filename is not a GIMP palette file";
      return;
    }
    my $line;
    my %pal;
    my $mod_time = (stat PAL)[9];
    while (defined($line = <PAL>)) {
      next if $line =~ /^#/ || $line =~ /^\s*$/;
      chomp $line;
      my ($r,$g, $b, $name) = split ' ', $line, 4;
      if ($name) {
        $name =~ s/\s*\([\d\s]+\)\s*$//;
        $pal{lc $name} = [ $r, $g, $b ];
      }
    }
    close PAL;

    $gimp_cache{$filename} = { mod_time=>$mod_time, colors=>\%pal };

    return 1;
  }
  else {
    $Imager::ERRSTR = "Cannot open palette file $filename: $!";
    return;
  }
}

sub _get_gimp_color {
  my %args = @_;

  my $filename;
  if ($args{palette}) {
    $filename = $args{palette};
  }
  elsif (defined $default_gimp_palette) {
    # don't search again and again and again ...
    if (!length $default_gimp_palette
	|| !-f $default_gimp_palette) {
      $Imager::ERRSTR = "No GIMP palette found";
      $default_gimp_palette = "";
      return;
    }

    $filename = $default_gimp_palette;
  }
  else {
    # try to make one up - this is intended to die if tainting is
    # enabled and $ENV{HOME} is tainted.  To avoid that untaint $ENV{HOME}
    # or set the palette parameter
    for my $attempt (@gimp_search) {
      my $work = $attempt; # don't modify the source array
      $work =~ /\$HOME/ && !defined $ENV{HOME}
	and next;
      $work =~ s/\$HOME/$ENV{HOME}/;
      if (-e $work) {
        $filename = $work;
        last;
      }
    }
    if (!$filename) {
      $Imager::ERRSTR = "No GIMP palette found";
      $default_gimp_palette = "";
      return ();
    }

    $default_gimp_palette = $filename;
  }

  if ((!$gimp_cache{$filename}
      || (stat $filename)[9] != $gimp_cache{$filename})
     && !_load_gimp_palette($filename)) {
    return ();
  }

  if (!$gimp_cache{$filename}{colors}{lc $args{name}}) {
    $Imager::ERRSTR = "Color '$args{name}' isn't in $filename";
    return ();
  }

  return @{$gimp_cache{$filename}{colors}{lc $args{name}}};
}

my @x_search =
  (
   '/usr/share/X11/rgb.txt', # newer Xorg X11 dists use this
   '/usr/lib/X11/rgb.txt', # seems fairly standard
   '/usr/local/lib/X11/rgb.txt', # seems possible
   '/usr/X11R6/lib/X11/rgb.txt', # probably the same as the first
   '/usr/openwin/lib/rgb.txt',
   '/usr/openwin/lib/X11/rgb.txt',
  );

my $default_x_rgb;

# called by the test code to check if we can test this stuff
sub _test_x_palettes {
  @x_search;
}

# x rgb.txt cache
# same structure as %gimp_cache
my %x_cache;

sub _load_x_rgb {
  my ($filename) = @_;

  local *RGB;
  if (open RGB, "< $filename") {
    my $line;
    my %pal;
    my $mod_time = (stat RGB)[9];
    while (defined($line = <RGB>)) {
      # the version of rgb.txt supplied with GNU Emacs uses # for comments
      next if $line =~ /^[!#]/ || $line =~ /^\s*$/;
      chomp $line;
      my ($r,$g, $b, $name) = split ' ', $line, 4;
      if ($name) {
        $pal{lc $name} = [ $r, $g, $b ];
      }
    }
    close RGB;

    $x_cache{$filename} = { mod_time=>$mod_time, colors=>\%pal };

    return 1;
  }
  else {
    $Imager::ERRSTR = "Cannot open palette file $filename: $!";
    return;
  }
}

sub _get_x_color {
  my %args = @_;

  my $filename;
  if ($args{palette}) {
    $filename = $args{palette};
  }
  elsif (defined $default_x_rgb) {
    unless (length $default_x_rgb) {
      $Imager::ERRSTR = "No X rgb.txt palette found";
      return ();
    }
    $filename = $default_x_rgb;
  }
  else {
    for my $attempt (@x_search) {
      if (-e $attempt) {
        $filename = $attempt;
        last;
      }
    }
    if (!$filename) {
      $Imager::ERRSTR = "No X rgb.txt palette found";
      $default_x_rgb = "";
      return ();
    }
  }

  if ((!$x_cache{$filename}
      || (stat $filename)[9] != $x_cache{$filename}{mod_time})
     && !_load_x_rgb($filename)) {
    return ();
  }

  $default_x_rgb = $filename;

  if (!$x_cache{$filename}{colors}{lc $args{name}}) {
    $Imager::ERRSTR = "Color '$args{name}' isn't in $filename";
    return ();
  }

  return @{$x_cache{$filename}{colors}{lc $args{name}}};
}

sub _pc_to_byte {
  POSIX::ceil($_[0] * 255 / 100);
}

sub _rgb_alpha {
  my ($alpha) = @_;
  if ($alpha =~ /^(.*)%\z/) {
    return POSIX::ceil($1 * 255 / 100);
  }
  else {
    return POSIX::ceil($alpha * 255);
  }
}

my $rgb_key = qr/rgba?/;
my $rgb_samp = qr/(\d+(?:\.\d*)?)/;
my $rgb_pc = qr/(\d+(?:\.\d*)?)%/;
my $rgb_sep = qr/ *[, ] */;
my $rgb_rgb = qr/$rgb_samp $rgb_sep $rgb_samp $rgb_sep $rgb_samp/x;
my $rgb_rgb_pc = qr/$rgb_pc $rgb_sep $rgb_pc $rgb_sep $rgb_pc/x;
my $rgb_alpha_sep = qr/ *[\/,] */;
my $rgb_alpha = qr/((?:\.\d+|\d+(?:\.\d*)?)%?)/;

# Parse color spec into an a set of 4 colors

sub _pspec {
  if (@_ == 1 && Scalar::Util::blessed($_[0])) {
    if ($_[0]->isa("Imager::Color")) {
      return $_[0]->rgba;
    } elsif ($_[0]->isa("Imager::Color::Float")) {
      return $_[0]->as_8bit->rgba;
    }
  }
  if (@_ == 1) {
    # CSS Color 4 says that color values are rounded to +Inf
    if ($_[0] =~ /\A$rgb_key\( *$rgb_rgb *\)\z/) {
      return ( POSIX::ceil($1), POSIX::ceil($2), POSIX::ceil($3), 255 );
    }
    elsif ($_[0] =~ /\A$rgb_key\( *$rgb_rgb_pc *\)\z/) {
      return ( _pc_to_byte($1), _pc_to_byte($2), _pc_to_byte($3), 255 );
    }
    elsif ($_[0] =~ /\A$rgb_key\( *$rgb_rgb$rgb_alpha_sep$rgb_alpha *\)\z/) {
      return ( POSIX::ceil($1), POSIX::ceil($2), POSIX::ceil($3), _rgb_alpha($4) );
    }
    elsif ($_[0] =~ /\A$rgb_key\( *$rgb_rgb_pc$rgb_alpha_sep$rgb_alpha *\)\z/) {
      return ( _pc_to_byte($1), _pc_to_byte($2), _pc_to_byte($3), _rgb_alpha($4) );
    }
  }

  return (@_,255) if @_ == 3 && !grep /[^\d.+eE-]/, @_;
  return (@_    ) if @_ == 4 && !grep /[^\d.+eE-]/, @_;
  if ($_[0] =~
      /^\#?([\da-f][\da-f])([\da-f][\da-f])([\da-f][\da-f])([\da-f][\da-f])/i) {
    return (hex($1),hex($2),hex($3),hex($4));
  }
  if ($_[0] =~ /^\#?([\da-f][\da-f])([\da-f][\da-f])([\da-f][\da-f])/i) {
    return (hex($1),hex($2),hex($3),255);
  }
  if ($_[0] =~ /^\#([\da-f])([\da-f])([\da-f])$/i) {
    return (hex($1) * 17, hex($2) * 17, hex($3) * 17, 255);
  }
  my %args;
  if (@_ == 1) {
    # a named color
    %args = ( name => @_ );
  }
  else {
    %args = @_;
  }
  my @result;
  if (exists $args{gray}) {
    @result = $args{gray};
  }
  elsif (exists $args{grey}) {
    @result = $args{grey};
  }
  elsif ((exists $args{red} || exists $args{r})
         && (exists $args{green} || exists $args{g})
         && (exists $args{blue} || exists $args{b})) {
    @result = ( exists $args{red} ? $args{red} : $args{r},
                exists $args{green} ? $args{green} : $args{g},
                exists $args{blue} ? $args{blue} : $args{b} );
  }
  elsif ((exists $args{hue} || exists $args{h})
         && (exists $args{saturation} || exists $args{'s'})
         && (exists $args{value} || exists $args{v})) {
    my $hue = exists $args{hue}        ? $args{hue}        : $args{h};
    my $sat = exists $args{saturation} ? $args{saturation} : $args{'s'};
    my $val = exists $args{value}      ? $args{value}      : $args{v};

    @result = _hsv_to_rgb($hue, $sat, $val);
  }
  elsif (exists $args{web}) {
    if ($args{web} =~ /^#?([\da-f][\da-f])([\da-f][\da-f])([\da-f][\da-f])$/i) {
      @result = (hex($1),hex($2),hex($3));
    }
    elsif ($args{web} =~ /^#?([\da-f])([\da-f])([\da-f])$/i) {
      @result = (hex($1) * 17, hex($2) * 17, hex($3) * 17);
    }
  }
  elsif ($args{name}) {
    unless (@result = _get_gimp_color(%args)) {
      unless (@result = _get_x_color(%args)) {
        require Imager::Color::Table;
        unless (@result = Imager::Color::Table->get($args{name})) {
          $Imager::ERRSTR = "No color named $args{name} found";
          return ();
        }
      }
    }
  }
  elsif ($args{gimp}) {
    @result = _get_gimp_color(name=>$args{gimp}, %args);
  }
  elsif ($args{xname}) {
    @result = _get_x_color(name=>$args{xname}, %args);
  }
  elsif ($args{builtin}) {
    require Imager::Color::Table;
    @result = Imager::Color::Table->get($args{builtin});
  }
  elsif ($args{rgb}) {
    @result = @{$args{rgb}};
  }
  elsif ($args{rgba}) {
    @result = @{$args{rgba}};
    return @result if @result == 4;
  }
  elsif ($args{hsv}) {
    @result = _hsv_to_rgb(@{$args{hsv}});
  }
  elsif ($args{channels}) {
    my @ch = @{$args{channels}};
    return ( @ch, (0) x (4 - @ch) );
  }
  elsif (exists $args{channel0} || $args{c0}) {
    my $i = 0;
    while (exists $args{"channel$i"} || exists $args{"c$i"}) {
      push(@result,
           exists $args{"channel$i"} ? $args{"channel$i"} : $args{"c$i"});
      ++$i;
    }
  }
  else {
    $Imager::ERRSTR = "No color specification found";
    return ();
  }
  if (@result) {
    if (exists $args{alpha} || exists $args{a}) {
      push(@result, exists $args{alpha} ? $args{alpha} : $args{a});
    }
    while (@result < 4) {
      push(@result, 255);
    }
    return @result;
  }
  return ();
}

sub new {
  shift; # get rid of class name.
  my @arg = _pspec(@_);
  return @arg ? new_internal($arg[0],$arg[1],$arg[2],$arg[3]) : ();
}

sub set {
  my $self = shift;
  my @arg = _pspec(@_);
  return @arg ? set_internal($self, $arg[0],$arg[1],$arg[2],$arg[3]) : ();
}

sub equals {
  my ($self, %opts) = @_;

  my $other = $opts{other}
    or return Imager->_set_error("'other' parameter required");
  my $ignore_alpha = $opts{ignore_alpha} || 0;

  my @left = $self->rgba;
  my @right = $other->rgba;
  my $last_chan = $ignore_alpha ? 2 : 3;
  for my $ch (0 .. $last_chan) {
    $left[$ch] == $right[$ch]
      or return;
  }

  return 1;
}

sub CLONE_SKIP { 1 }

# Lifted from Graphics::Color::RGB
# Thank you very much
sub hsv {
    my( $self ) = @_;

    my( $red, $green, $blue, $alpha ) = $self->rgba;
    my $max = $red;
    my $maxc = 'r';
    my $min = $red;

    if($green > $max) {
        $max = $green;
        $maxc = 'g';
    }
    if($blue > $max) {
        $max = $blue;
        $maxc = 'b';
    }

    if($green < $min) {
        $min = $green;
    }
    if($blue < $min) {
        $min = $blue;
    }

    my ($h, $s, $v);

    if($max == $min) {
        $h = 0;
    }
    elsif($maxc eq 'r') {
        $h = 60 * (($green - $blue) / ($max - $min)) % 360;
    }
    elsif($maxc eq 'g') {
        $h = (60 * (($blue - $red) / ($max - $min)) + 120);
    }
    elsif($maxc eq 'b') {
        $h = (60 * (($red - $green) / ($max - $min)) + 240);
    }

    $v = $max/255;
    if($max == 0) {
        $s = 0;
    }
    else {
        $s = 1 - ($min / $max);
    }

    return int($h), $s, $v, $alpha;
}

sub as_float {
  my ($self) = @_;

  return Imager::Color::Float->new(map { $_ / 255 } $self->rgba);
}

sub as_css_rgb {
  my ($self) = @_;

  my ($r, $g, $b, $alpha) = $self->rgba;

  if ($alpha == 255) {
    return "rgb($r, $g, $b)";
  }
  else {
    my $ac = POSIX::floor($alpha * 1000 / 255) / 10;
    if (POSIX::ceil(POSIX::floor($ac/10) * 10 * 255 / 100) == $alpha) {
      # simple one decimal fraction
      $ac = POSIX::floor($ac/10)/10;
    }
    elsif (POSIX::ceil(POSIX::floor($ac) * 255 / 100) == $alpha) {
      $ac = POSIX::floor($ac) . "%";
    }
    else {
      $ac = "$ac%";
    }
    return "rgba($r, $g, $b, $ac)";
  }
}

1;

__END__

=head1 NAME

Imager::Color - Color handling for Imager.

=head1 SYNOPSIS

  use Imager;

  $color = Imager::Color->new($red, $green, $blue);
  $color = Imager::Color->new($red, $green, $blue, $alpha);
  $color = Imager::Color->new("#C0C0FF"); # html color specification

  $color->set($red, $green, $blue);
  $color->set($red, $green, $blue, $alpha);
  $color->set("#C0C0FF"); # html color specification

  ($red, $green, $blue, $alpha) = $color->rgba();
  @hsv = $color->hsv();

  $color->info();

  if ($color->equals(other=>$other_color)) {
    ...
  }


=head1 DESCRIPTION

This module handles creating color objects used by Imager.  The idea
is that in the future this module will be able to handle color space
calculations as well.

An Imager color consists of up to four components, each in the range 0
to 255. Unfortunately the meaning of the components can change
depending on the type of image you're dealing with:

=over

=item *

for 3 or 4 channel images the color components are red, green, blue,
alpha.

=item *

for 1 or 2 channel images the color components are gray, alpha, with
the other two components ignored.

=back

An alpha value of zero is fully transparent, an alpha value of 255 is
fully opaque.

=head1 METHODS

=over 4

=item new

This creates a color object to pass to functions that need a color argument.

=item set

This changes an already defined color.  Note that this does not affect any places
where the color has been used previously.

=item rgba()

This returns the red, green, blue and alpha channels of the color the
object contains.

=item info

Calling info merely dumps the relevant color to the log.

=item equals(other=>$other_color)

=item equals(other=>$other_color, ignore_alpha=>1)

Compares $self and color $other_color returning true if the color
components are the same.

Compares all four channels unless C<ignore_alpha> is set.  If
C<ignore_alpha> is set only the first three channels are compared.

=back

You can specify colors in several different ways, you can just supply
simple values:

=over

=item *

an Imager::Color object

=item *

an Imager::Color::Float object, the ranges of samples are translated from 0.0...1.0 to 0...255.

=item *

simple numeric parameters - if you supply 3 or 4 numeric arguments, you get a color made up of those RGB (and possibly A) components.

=item *

a six hex digit web color, either C<RRGGBB> or C<#RRGGBB>

=item *

an eight hex digit web color, either C<RRGGBBAA> or C<#RRGGBBAA>.

=item *

a CSS rgb() color, based on CSS Color 4.  The C<none> keyword is not
supported and numbers must be simple decimals without exponents. eg.

  rgb(50% 50% 100%)
  rgb(0, 0, 255)
  rgb(0.5 0.5 1.0 / 0.8)
  rgb(50%, 50%, 100%, 80%)

Samples from percentages or decimals are rounded up per CSS Color 3 and 4.

This accepts some colors not accepted by the CSS rgb() specification,
this may change.

=item *

a 3 hex digit web color, C<#RGB> - a value of F becomes 255.

=item *

a color name, from whichever of the gimp C<Named_Colors> file or X
C<rgb.txt> is found first.  The same as using the C<name> keyword.

=back

You can supply named parameters:

=over

=item *

'red', 'green' and 'blue', optionally shortened to 'r', 'g' and 'b'.
The color components in the range 0 to 255.

 # all of the following are equivalent
 my $c1 = Imager::Color->new(red=>100, blue=>255, green=>0);
 my $c2 = Imager::Color->new(r=>100, b=>255, g=>0);
 my $c3 = Imager::Color->new(r=>100, blue=>255, g=>0);

=item *

C<hue>, C<saturation> and C<value>, optionally shortened to C<h>, C<s> and
C<v>, to specify a HSV color.  0 <= hue < 360, 0 <= s <= 1 and 0 <= v
<= 1.

  # the same as RGB(127,255,127)
  my $c1 = Imager::Color->new(hue=>120, v=>1, s=>0.5);
  my $c1 = Imager::Color->new(hue=>120, value=>1, saturation=>0.5);

=item *

C<web>, which can specify a 6 or 3 hex digit web color, in any of the
forms C<#RRGGBB>, C<#RGB>, C<RRGGBB> or C<RGB>.

  my $c1 = Imager::Color->new(web=>'#FFC0C0'); # pale red

=item *

C<gray> or C<grey> which specifies a single channel, from 0 to 255.

  # exactly the same
  my $c1 = Imager::Color->new(gray=>128);
  my $c1 = Imager::Color->new(grey=>128);

=item *

C<rgb> which takes a 3 member arrayref, containing each of the red,
green and blue values.

  # the same
  my $c1 = Imager::Color->new(rgb=>[255, 100, 0]);
  my $c1 = Imager::Color->new(r=>255, g=>100, b=>0);

=item *

C<hsv> which takes a 3 member arrayref, containing each of hue,
saturation and value.

  # the same
  my $c1 = Imager::Color->new(hsv=>[120, 0.5, 1]);
  my $c1 = Imager::Color->new(hue=>120, v=>1, s=>0.5);

=item *

C<gimp> which specifies a color from a GIMP palette file.  You can
specify the file name of the palette file with the 'palette'
parameter, or let Imager::Color look in various places, typically
C<$HOME/gimp-1.x/palettes/Named_Colors> with and without the version
number, and in C</usr/share/gimp/palettes/>.  The palette file must
have color names.

  my $c1 = Imager::Color->new(gimp=>'snow');
  my $c1 = Imager::Color->new(gimp=>'snow', palette=>'testimg/test_gimp_pal);

=item *

C<xname> which specifies a color from an X11 C<rgb.txt> file.  You can
specify the file name of the C<rgb.txt> file with the C<palette>
parameter, or let Imager::Color look in various places, typically
C</usr/lib/X11/rgb.txt>.

  my $c1 = Imager::Color->new(xname=>'blue') # usually RGB(0, 0, 255)

=item *

C<builtin> which specifies a color from the built-in color table in
Imager::Color::Table.  The colors in this module are the same as the
default X11 C<rgb.txt> file.

  my $c1 = Imager::Color->new(builtin=>'black') # always RGB(0, 0, 0)

=item *

C<name> which specifies a name from either a GIMP palette, an X
C<rgb.txt> file or the built-in color table, whichever is found first.

=item *

'channel0', 'channel1', etc, each of which specifies a single channel.  These can be abbreviated to 'c0', 'c1' etc.

=item *

'channels' which takes an arrayref of the channel values.

=back

Optionally you can add an alpha channel to a color with the 'alpha' or
'a' parameter.

These color specifications can be used for both constructing new
colors with the new() method and modifying existing colors with the
set() method.

=head1 METHODS

=over

=item hsv()

    my($h, $s, $v, $alpha) = $color->hsv();

Returns the color as a Hue/Saturation/Value/Alpha tuple.

=item red

=item green

=item blue

=item alpha

Returns the respective component as an integer from 0 to 255.

=item as_float

Returns the color as a L<Imager::Color::Float> object.

=item as_css_rgb

Returns the color as a CSS rgb() format color.  This is always
returned in the byte form, eg. rgb(255 128 64).

If the alpha is not full coverage (255) it will be rounded if the
result of converting the color back to an 8 bit color would return the
same alpha, eg. if the color alpha is 128, it will be formatted as
0.5, not as the more precise 50.2%.

=back

=head1 AUTHOR

Arnar M. Hrafnkelsson, addi@umich.edu
And a great deal of help from others - see the C<README> for a complete
list.

=head1 SEE ALSO

Imager(3), Imager::Color
http://imager.perl.org/

=cut
